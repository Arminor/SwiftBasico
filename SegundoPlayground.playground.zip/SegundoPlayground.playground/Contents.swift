import UIKit

//Strings de nuevo

// Recordad que para utilizar un caracter especial usamos el: \  (backslash) antes de colocarlo
print("\' \\/ \\ \n\' \' \\/ \\ \" \" \n")

var unCaracter = "a"

var otroCaracter : Character = "a"




var saludo: String = ""
var despedida: String = ""
var booleano: Bool = true


if booleano {
    saludo = "Hola! Cómo estás, te ves muy, muy muy ... muy bien hoy!!!! :)"
    despedida = "Luego nos vemos. Que te vaya muy bien hoy. Excelente día!!! <3"
    print(saludo + "\n" + despedida)
}else{
    saludo = "Ahhh ya llegaste. Ya me voy"
    despedida = "..."
    print(saludo, despedida, "(me caes super mal)")
}







var misNombres: String = "Andres Miguel"
var misApellidos: String = "Ríos Minor"


misNombres += " \(misApellidos). Eres aceptado. Te esperamos mañana."

misNombres += "Hola, Soy += un operador compuesto, con sobrecarga de métodos :)))"
misNombres


var palabraLarga: String = "Parangaricutirimicuaro"

var cadenaLarga: String = """
Ojalá que las hojas no te toquen el cuerpo cuando caigan
Para que no las puedas convertir en cristal
Ojalá que la lluvia deje de ser milagro que baja por tu cuerpo
Ojalá que la luna pueda salir sin tí
Ojalá que la tierra no te bese los pasos
Ojalá se te acabe la mirada constante
La palabra precisa la sonrisa perfecta
Ojalá pase algo que te borre de pronto
Una luz cegadora, un disparo de nieve
Ojalá por lo menos que me lleve la muerte
Para no verte tanto, para no verte siempre
En todos los segundos, en todas las visiones
Ojalá que no pueda tocarte ni en canciones
Ojalá que la aurora no de gritos que caigan en mi espalda
Ojalá que tu nombre se le olvide esa voz
Ojalá las paredes no retengan tu ruido de camino cansado
Ojalá que el deseo se vaya tras de tí
A tu viejo gobierno de difuntos y flores
Ojalá se te acabe la mirada constante
La palabra precisa la sonrisa perfecta
Ojalá pase algo que te borre de pronto
Una luz cegadora, un disparo de nieve
Ojalá por lo menos que me lleve la muerte
Para no verte tanto, para no verte siempre
En todos los segundos, en todas las visiones
Ojalá que no pueda tocarte ni en canciones
Ojalá pase algo que te borre de pronto
Una luz cegadora, un disparo de nieve
Ojalá por lo menos que me lleve la muerte
Para no verte tanto, para no verte siempre
En todos los segundos, en todas las visiones
Ojalá que no pueda tocarte ni en canciones
"""

var letrasEnPalabraLarga: Int = palabraLarga.count
var totalDeCaracteresEnCadena: Int = cadenaLarga.count


var inputPassword: String = ""


if inputPassword.count < 12{
    print("Su contraseña no puede ser menor a 12 caracteres. Ojo ahí")
}



var caracter: Character = "e"
var esVocal : Bool

switch caracter {
case "a","e", "i", "o", "u":
    esVocal = true
default:
    esVocal = false
}

if esVocal{
    print("\'\(caracter)\' efectivamente es una vocal")
}else{
    print("\'\(caracter)\' no es vocal mi hermano")
}



//Nuevamente un Arreglo

var someNumbers: [Int] = [1,2,3,4,6,5,7,4]

someNumbers.count

if someNumbers.contains(4){
    print("El arreglo tiene por lo menos un cuatro. (4)")
}


var nuevoArreglo = [Int](repeating: 0, count: 1000)

nuevoArreglo.count

if nuevoArreglo.isEmpty == false{
    print("Tu arreglo no esta para nada vacío amiguito")
}


//Estructuras y Clases

//Una estructura o registro no tiene las cualidades de una clase
struct persona{
    var nombre: String
    
    init(x: String){
        self.nombre = x
    }
    
    func saludar(){
    print("Hola amigo")
    }
}

class Person{
    var name: String
    
    init(x: String){
        self.name = x
    }
    
    func sayHello(){
    print("Hi my friend")
    }
}

class Student: Person{}
//struct estudiante: Person{}

var cualquierEstudiante: Student = Student(x: "Andres")

cualquierEstudiante.name
cualquierEstudiante.sayHello()

//Clases abstactas y herencia

class Clase{
    var atributo: Int
    var atributo2: Double
    init(atributo: Int, atributo2: Double){
        self.atributo = atributo
        self.atributo2 = atributo2
    }
}

class FirstSubclass: Clase{
    
}

class SecondSubclass: Clase{
    
}

var nuevoObjeto: FirstSubclass = FirstSubclass(atributo: 1, atributo2: 10.0)



var array: [FirstSubclass]

var otherArray: [SecondSubclass]



var numeroDeMes: Int
var nombreMes: String


// Una tupla
var tupla: [Int: String] = [8: "Agosto"]







//Dictionariees
var diccion: Dictionary<Int, String>
var diccionario: [Int: String]
    
    diccion = [1: "Enero", 2: "Febrero", 3: "Marzo",
              4: "Abril", 5: "Mayo", 6: "Junio", 7:"Julio",
              8:"Agosto", 9: "Septiembre", 10: "Octubre",
              11: "Noviembre", 12: "Diciambre"]


for (numeroMes, nombreMes) in diccion{
    print ("El numero de mes es \(numeroMes) y el nombre del mes es \(nombreMes)")
}

diccion.count
diccion.capacity


//Sets. Es basicamente un arreglo, en donde no puedo repetir los valores.

var iOSDevelopmentLabTeam : Set = ["Andres", "Jacobo", "Karen", "Eric", "Gabriel", "Cristian", "Fernando"]

var otroSet: Set = [1,2,3,4,5,6,7,8,9,10]









//Interface Builder




